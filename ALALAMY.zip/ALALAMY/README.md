# Alamy
